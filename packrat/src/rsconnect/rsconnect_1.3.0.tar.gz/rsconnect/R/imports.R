

#' @importFrom stats na.omit setNames
#' @importFrom utils available.packages installed.packages contrib.url getFromNamespace glob2rx packageVersion packageDescription read.csv
NULL
