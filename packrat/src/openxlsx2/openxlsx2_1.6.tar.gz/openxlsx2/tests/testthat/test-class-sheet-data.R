
test_that("class wbSheetData works", {
  expect_null(assert_sheet_data(wb_sheet_data()))
})
