library(testthat)
library(openxlsx2)

test_check("openxlsx2")
